import os
import aiosqlite
from config import DATABASE_PATH

_db_dir = os.path.dirname(DATABASE_PATH)
if _db_dir:
    os.makedirs(_db_dir, exist_ok=True)


class Database:
    def __init__(self, path=DATABASE_PATH):
        self.path = path

    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS posted_news (
                    article_id TEXT PRIMARY KEY,
                    title TEXT,
                    url TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS channels (
                    chat_id TEXT PRIMARY KEY,
                    username TEXT,
                    title TEXT,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            await db.commit()

    async def is_posted(self, article_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT 1 FROM posted_news WHERE article_id = ? LIMIT 1",
                (article_id,),
            )
            row = await cur.fetchone()
            return row is not None

    async def mark_posted(self, article_id, title, url):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT OR IGNORE INTO posted_news(article_id,title,url) VALUES(?,?,?)",
                (article_id, title, url),
            )
            await db.commit()

    async def add_channel(self, chat_id, username="", title=""):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT OR REPLACE INTO channels(chat_id,username,title) VALUES(?,?,?)",
                (str(chat_id), username, title),
            )
            await db.commit()

    async def remove_channel(self, chat_id):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "DELETE FROM channels WHERE chat_id = ?",
                (str(chat_id),),
            )
            await db.commit()

    async def get_channels(self):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT chat_id, username, title FROM channels ORDER BY added_at"
            )
            return await cur.fetchall()
