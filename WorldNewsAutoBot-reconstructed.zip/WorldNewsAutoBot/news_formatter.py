import re
from html import escape

CATEGORY_WORDS = {
    "Football": [
        "football", "soccer", "premier league", "champions league",
        "uefa", "fifa", "arsenal", "chelsea", "liverpool", "manchester",
        "barcelona", "real madrid"
    ],
    "Basketball": ["nba", "basketball", "wnba"],
    "Tennis": ["tennis", "atp", "wta", "grand slam", "wimbledon", "us open"],
    "Politics": ["president", "election", "government", "minister", "senate", "parliament"],
    "Business": ["business", "market", "stock", "economy", "company", "bank"],
    "Technology": ["technology", "tech", "ai", "artificial intelligence", "software", "iphone"],
    "Entertainment": ["movie", "film", "music", "celebrity", "actor", "actress"],
    "Health": ["health", "hospital", "disease", "medical", "doctor"],
}


def categories(title):
    text = title.lower()
    found = []
    for category, words in CATEGORY_WORDS.items():
        if any(re.search(r"\b" + re.escape(word) + r"\b", text) for word in words):
            found.append(category)
    return found or ["WorldNews"]


def format_article(article):
    tags = " ".join("#" + re.sub(r"[^A-Za-z0-9]", "", x) for x in categories(article.title))
    source = escape(article.source or "News source")
    title = escape(article.title)

    return (
        f"🌍 <b>{title}</b>\n\n"
        f"📰 Source: {source}\n"
        f"{tags}\n\n"
        f"🔗 <a href=\"{escape(article.url, quote=True)}\">Read full story</a>"
    )
