import hashlib
import html
import re
import time
from dataclasses import dataclass
from typing import Optional

import aiohttp
import feedparser


@dataclass
class Article:
    article_id: str
    title: str
    url: str
    summary: str
    image_url: Optional[str] = None
    published: Optional[str] = None
    source: Optional[str] = None


def clean_text(value: str) -> str:
    value = re.sub(r"<[^>]+>", " ", value or "")
    value = html.unescape(value)
    return re.sub(r"\s+", " ", value).strip()


def get_image(entry):
    media = entry.get("media_content") or entry.get("media_thumbnail") or []
    if media and isinstance(media, list):
        for item in media:
            if item.get("url"):
                return item["url"]

    for link in entry.get("links", []):
        typ = (link.get("type") or "").lower()
        href = link.get("href")
        if href and typ.startswith("image/"):
            return href

    return None


async def fetch_feed(session, feed_url):
    try:
        async with session.get(
            feed_url,
            timeout=aiohttp.ClientTimeout(total=20),
            headers={"User-Agent": "WorldNewsAutoBot/1.0"},
        ) as response:
            if response.status != 200:
                return []
            data = await response.read()

        parsed = feedparser.parse(data)
        source = parsed.feed.get("title", feed_url)

        articles = []
        for entry in parsed.entries[:30]:
            title = clean_text(entry.get("title", ""))
            url = entry.get("link", "").strip()
            summary = clean_text(entry.get("summary", entry.get("description", "")))

            if not title or not url:
                continue

            article_id = hashlib.sha256(url.encode("utf-8")).hexdigest()

            published = (
                entry.get("published")
                or entry.get("updated")
                or entry.get("pubDate")
            )

            articles.append(
                Article(
                    article_id=article_id,
                    title=title,
                    url=url,
                    summary=summary[:700],
                    image_url=get_image(entry),
                    published=published,
                    source=source,
                )
            )

        return articles
    except Exception:
        return []


async def fetch_all(feed_urls):
    connector = aiohttp.TCPConnector(limit=10, ssl=False)
    async with aiohttp.ClientSession(connector=connector) as session:
        results = await __import__("asyncio").gather(
            *(fetch_feed(session, url) for url in feed_urls)
        )

    unique = {}
    for batch in results:
        for article in batch:
            unique[article.article_id] = article

    return list(unique.values())
