import asyncio
import logging
import os
from contextlib import suppress

from aiogram import Bot, Dispatcher
from aiogram.filters import Command, CommandStart
from aiogram.types import Message
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError

from config import BOT_TOKEN, ADMIN_ID, CHANNELS, RSS_FEEDS, POST_INTERVAL
from database import Database
from news_formatter import format_article
from rss_fetcher import fetch_all

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

dp = Dispatcher()
db = Database()
channels_lock = asyncio.Lock()


def is_admin(message: Message) -> bool:
    return bool(
        ADMIN_ID
        and message.from_user
        and message.from_user.id == ADMIN_ID
    )


async def resolve_chat(bot: Bot, value: str):
    value = value.strip()
    if value.startswith("https://t.me/"):
        value = "@" + value.rstrip("/").split("/")[-1]
    elif value.startswith("t.me/"):
        value = "@" + value.rstrip("/").split("/")[-1]
    elif not value.startswith("@") and not value.lstrip("-").isdigit():
        value = "@" + value

    chat = await bot.get_chat(value)
    return chat


@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "🌍 <b>World News Auto Bot</b>\n\n"
        "The bot is online.\n"
        "Use /help to see available commands."
    )


@dp.message(Command("help"))
async def help_command(message: Message):
    text = (
        "🌍 <b>World News Auto Bot</b>\n\n"
        "/status — check bot status\n"
        "/channels — show configured channels\n"
        "/addchannel @username — add a channel\n"
        "/removechannel @username — remove a channel\n\n"
        "Channel commands require the configured ADMIN_ID."
    )
    await message.answer(text)


@dp.message(Command("status"))
async def status(message: Message, bot: Bot):
    me = await bot.get_me()
    channels = await db.get_channels()
    await message.answer(
        f"✅ <b>Bot is online</b>\n\n"
        f"🤖 @{me.username}\n"
        f"📡 Channels: {len(channels)}"
    )


@dp.message(Command("channels"))
async def list_channels(message: Message):
    rows = await db.get_channels()
    if not rows:
        await message.answer(
            "📭 No channels have been added yet.\n\n"
            "Admin: use /addchannel @channelusername"
        )
        return

    lines = ["📡 <b>Configured channels</b>\n"]
    for i, (chat_id, username, title) in enumerate(rows, 1):
        label = username or title or chat_id
        lines.append(f"{i}. {label} <code>{chat_id}</code>")

    await message.answer("\n".join(lines))


@dp.message(Command("addchannel"))
async def add_channel(message: Message, bot: Bot):
    if not is_admin(message):
        await message.answer("⛔ Admin only.")
        return

    parts = (message.text or "").split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage: /addchannel @channelusername")
        return

    target = parts[1].strip()

    try:
        chat = await resolve_chat(bot, target)

        if chat.type not in ("channel", "supergroup"):
            await message.answer("❌ That is not a Telegram channel/group.")
            return

        # Bot must be an administrator in the target channel to post.
        bot_member = await bot.get_chat_member(chat.id, (await bot.get_me()).id)
        if bot_member.status not in ("administrator", "creator"):
            await message.answer(
                "❌ Add this bot as an administrator in the channel first, "
                "then run /addchannel again."
            )
            return

        username = f"@{chat.username}" if chat.username else ""
        await db.add_channel(chat.id, username, chat.title or "")

        await message.answer(
            f"✅ Added <b>{chat.title or username or chat.id}</b>\n"
            f"🆔 <code>{chat.id}</code>"
        )
    except TelegramBadRequest as e:
        await message.answer(
            "❌ Telegram could not find/access that channel.\n"
            "Make sure the username is correct and the bot is in the channel."
        )
        logging.warning("addchannel Telegram error: %s", e)
    except Exception as e:
        logging.exception("addchannel failed")
        await message.answer(f"❌ Could not add channel: {type(e).__name__}")


@dp.message(Command("removechannel"))
async def remove_channel(message: Message, bot: Bot):
    if not is_admin(message):
        await message.answer("⛔ Admin only.")
        return

    parts = (message.text or "").split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage: /removechannel @channelusername")
        return

    try:
        chat = await resolve_chat(bot, parts[1])
        await db.remove_channel(chat.id)
        await message.answer("✅ Channel removed.")
    except Exception:
        await message.answer("❌ Could not find that channel.")


async def seed_channels(bot: Bot):
    for value in CHANNELS:
        try:
            chat = await resolve_chat(bot, value)
            await db.add_channel(
                chat.id,
                f"@{chat.username}" if chat.username else "",
                chat.title or "",
            )
        except Exception as e:
            logging.warning("Could not seed channel %s: %s", value, e)


async def publishing_loop(bot: Bot):
    while True:
        try:
            articles = await fetch_all(RSS_FEEDS)

            # Newest feeds are checked first. Post only articles not seen before.
            for article in articles:
                if await db.is_posted(article.article_id):
                    continue

                rows = await db.get_channels()
                if not rows:
                    break

                text = format_article(article)
                sent_any = False

                for chat_id, _, _ in rows:
                    try:
                        await bot.send_message(
                            chat_id=int(chat_id),
                            text=text,
                            disable_web_page_preview=False,
                        )
                        sent_any = True
                        await asyncio.sleep(1)
                    except (TelegramBadRequest, TelegramForbiddenError) as e:
                        logging.warning(
                            "Could not post to %s: %s",
                            chat_id,
                            e,
                        )
                    except Exception:
                        logging.exception("Unexpected channel posting error")

                # Mark globally only after at least one successful delivery.
                if sent_any:
                    await db.mark_posted(
                        article.article_id,
                        article.title,
                        article.url,
                    )

                # Avoid flooding Telegram.
                await asyncio.sleep(POST_INTERVAL)

        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception("Publishing loop error")

        await asyncio.sleep(30)


async def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Add it to Railway Variables.")

    await db.init()

    bot = Bot(token=BOT_TOKEN)

    me = await bot.get_me()
    logging.info("Logged in as @%s", me.username)

    await seed_channels(bot)

    publisher = asyncio.create_task(publishing_loop(bot))

    try:
        await dp.start_polling(bot)
    finally:
        publisher.cancel()
        with suppress(asyncio.CancelledError):
            await publisher
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
