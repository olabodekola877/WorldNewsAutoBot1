import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0") or "0")

# Optional comma-separated initial channels.
# Example: CHANNELS=@channelone,@channeltwo,-1001234567890
CHANNELS = [
    x.strip()
    for x in os.getenv("CHANNELS", "").split(",")
    if x.strip()
]

CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL", "30"))
POST_INTERVAL = int(os.getenv("POST_INTERVAL", "60"))
DATABASE_PATH = os.getenv("DATABASE_PATH", "data/worldnews.db")

# Worldwide general-news RSS feeds.
RSS_FEEDS = [
    "https://feeds.bbci.co.uk/news/rss.xml",
    "https://feeds.bbci.co.uk/news/world/rss.xml",
    "https://feeds.bbci.co.uk/news/business/rss.xml",
    "https://feeds.bbci.co.uk/news/technology/rss.xml",
    "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml",
    "https://feeds.bbci.co.uk/sport/rss.xml",
    "https://rss.nytimes.com/services/xml/rss/nyt/World.xml",
    "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml",
    "https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml",
    "https://www.aljazeera.com/xml/rss/all.xml",
]
