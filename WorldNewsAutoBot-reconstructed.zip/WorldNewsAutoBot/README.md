# WorldNewsAutoBot

Telegram worldwide news automation bot.

## Railway variables

Required:
- `BOT_TOKEN` = your existing Telegram bot token
- `ADMIN_ID` = your Telegram numeric user ID

Optional:
- `CHANNELS` = comma-separated channel usernames/IDs
- `DATABASE_PATH` = `data/worldnews.db`
- `POST_INTERVAL` = `60`

## Railway start command

```text
python main.py
```

After deployment:
1. Start the bot with `/start`.
2. Add the bot as administrator to each target channel.
3. From the admin Telegram account, use `/addchannel @channelusername`.
4. Use `/channels` to verify.
5. Use `/status` to verify the bot is online.
